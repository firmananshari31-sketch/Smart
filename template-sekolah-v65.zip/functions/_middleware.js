/* Gerbang kata sandi untuk Cloudflare Pages.
   Kata sandi diambil dari variabel rahasia KATA_SANDI di dashboard Cloudflare, bukan dari berkas ini.
   Username boleh diisi apa saja; yang dicek hanya kata sandinya. */

function samaAman(a, b) {
  if (a.length !== b.length) return false;
  let selisih = 0;
  for (let i = 0; i < a.length; i++) selisih |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return selisih === 0;
}

function bacaKataSandi(header) {
  if (!header || !header.startsWith('Basic ')) return null;
  try {
    const biner = Uint8Array.from(atob(header.slice(6)), (c) => c.charCodeAt(0));
    const teks = new TextDecoder().decode(biner);
    const titik = teks.indexOf(':');
    return titik === -1 ? null : teks.slice(titik + 1);
  } catch (e) {
    return null;
  }
}

export async function onRequest(context) {
  const kataSandi = context.env.KATA_SANDI;
  if (!kataSandi) {
    return new Response('Kata sandi belum diatur di Cloudflare (variabel KATA_SANDI).', { status: 500 });
  }
  const masukan = bacaKataSandi(context.request.headers.get('Authorization'));
  if (masukan !== null && samaAman(masukan, kataSandi)) {
    return context.next();
  }
  return new Response('Perlu kata sandi untuk membuka aplikasi ini.', {
    status: 401,
    headers: { 'WWW-Authenticate': 'Basic realm="Pindai", charset="UTF-8"' },
  });
}
